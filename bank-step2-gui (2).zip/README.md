# Banking System - CSE202 Part B

## Step 1: Core model (done)
Domain classes in `com.bank.model` with unit tests in `src/test`.

## Step 2: GUI (login screen)
`com.bank.view.LoginView` is a boundary class. It draws the form and passes the typed
username and password to a listener. It has no business logic. `MainApp` starts the window.

## Run in GitHub Codespaces
1. `mvn test` runs the 10 model tests.
2. `mvn javafx:run` starts the login window.
3. Open the Ports tab, click the globe next to port 6080, and log in with password `vscode`.
